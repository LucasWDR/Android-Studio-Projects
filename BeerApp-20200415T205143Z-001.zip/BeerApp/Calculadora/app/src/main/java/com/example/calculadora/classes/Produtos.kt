package com.example.calculadora.classes

data class Produtos(var marca: String, var volume: Int, var valor: Double = 0.0){
    var

    fun calcula(valor:Double, volume: Int) {
        val x = (valor * 1) / volume
        val resultado = x * 1000
        return resultado

        /*PARTE DE PASSAR O VALOR CONVERTIDO ANTES DE ADD NA RECYCLEVIEW NAO  ROLOU KKK */
    }
}
